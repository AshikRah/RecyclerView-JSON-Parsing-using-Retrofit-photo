# RetrofitTutorial
A simple android application that uses Retrofit library to read data from a REST api.
This is sample project created for a tutorial published here

[RetrofitAndroidTutorial](https://medium.com/@prakash_pun/retrofit-a-simple-android-tutorial-48437e4e5a23)

The project uses following libraries

1. https://github.com/square/picasso 
2. https://github.com/square/retrofit


Also, it uses http://jsonplaceholder.typicode.com/ to fetch sample JSON data.
